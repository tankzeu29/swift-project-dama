import XCTest

import BoardColoursTests

var tests = [XCTestCaseEntry]()
tests += BoardColoursTests.allTests()
XCTMain(tests)
