# BoardColours

This package is responsible for the allowed colours in the game
