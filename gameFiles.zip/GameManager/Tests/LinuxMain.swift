import XCTest

import GameManagerTests

var tests = [XCTestCaseEntry]()
tests += GameManagerTests.allTests()
XCTMain(tests)
