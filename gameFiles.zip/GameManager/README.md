# GameManager

This package is responsible for the Initializing game modules of the game 
