
import Foundation


//game result messages

public class GameResultMessages {
    public static let DRAW = "The result of the game is draw"
    public static let PLAYER1_WON = "Player1 won the game"
    public static let PLAYER2_WON = "Player2 won the game"
    public static let UNDETERMINED_WINNER = "Unable to determine winner"
    
}
