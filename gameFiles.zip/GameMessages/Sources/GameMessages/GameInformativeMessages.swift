
//game informative messages

public class GameInputMessages
{
    
    
    public static let ENTER_INPUT =  "Please enter input to put figure on the board"
    public static let ENTER_INPUT_MOVE =  "Please enter input to move figure on the board"
    public static let ENTER_INPUT_REMOVE_POINT =  "Please enter input to remove oponent's point"
}
