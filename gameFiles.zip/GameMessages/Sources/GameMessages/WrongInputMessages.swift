
/* Wrong user input display messages 
 */

import Foundation

public class WrongInputMessages{
    public static let ENTER_INPUT_PLACE = "Please enter again input to place figure on the board"
    public static let ENTER_INPUT_MOVE = "Please enter again input to move figure on the board"
    public static let ENTER_INPUT_AGAIN = "Please enter input again"
    public static let ENTER_VALID_POINT = "Please enter valid point to remove "
}
