import XCTest

import GameMessagesTests

var tests = [XCTestCaseEntry]()
tests += GameMessagesTests.allTests()
XCTMain(tests)
