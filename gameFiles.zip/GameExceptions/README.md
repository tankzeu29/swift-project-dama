# GameExceptions

This package is responsible for the error messages
