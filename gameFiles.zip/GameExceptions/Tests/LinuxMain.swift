import XCTest

import GameExceptionsTests

var tests = [XCTestCaseEntry]()
tests += GameExceptionsTests.allTests()
XCTMain(tests)
