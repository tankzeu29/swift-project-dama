
public enum NineMortisError: Error {
    case runtimeError(String)
    
    
}
