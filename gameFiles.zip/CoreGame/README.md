# CoreGame

This package contains the core classes representing the game
