
//Represents the end game state 
public enum EndGameState
{
    case PLAYER1_WINNER
    case PLAYER2_WINNER
    case IN_PROGRESS
    
}
