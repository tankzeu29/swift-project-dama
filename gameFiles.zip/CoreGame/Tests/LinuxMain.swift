import XCTest

import CoreGameTests

var tests = [XCTestCaseEntry]()
tests += CoreGameTests.allTests()
XCTMain(tests)
