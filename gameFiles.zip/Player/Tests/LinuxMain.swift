import XCTest

import PlayerTests

var tests = [XCTestCaseEntry]()
tests += PlayerTests.allTests()
XCTMain(tests)
