struct Player {
    var text = "Hello, World!"
}
