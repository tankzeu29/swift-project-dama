import XCTest

import ApplicationTests

var tests = [XCTestCaseEntry]()
tests += ApplicationTests.allTests()
XCTMain(tests)
