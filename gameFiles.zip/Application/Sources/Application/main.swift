
import GameManager
import Foundation

let manager = GameManager()
manager.startGame()

